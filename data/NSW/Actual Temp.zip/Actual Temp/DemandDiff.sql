select x.DATETIME,x.LASTCHANGED ,x.FORECASTDEMAND, n.TOTALDEMAND,m.TEMPERATURE
,ROUND(m.TEMPERATURE,0) as 'Temp Rounded'
,n.TOTALDEMAND - x.FORECASTDEMAND as 'Diff'

from (
select distinct

  w.LASTCHANGED,
           ABS(ABS(DATEDIFF(SECOND, w.LASTCHANGED, w.DATETIME)) - 86400) AS TimeDiff,
           RANK() OVER (partition by w.DATETIME ORDER BY ABS(ABS(DATEDIFF(SECOND, w.LASTCHANGED, w.DATETIME)) - 86400) ) AS RankValue,
		   w.DATETIME,
		   w.FORECASTDEMAND

from forecastdemand_nsw w
) x 
left join totaldemand_nsw n on n.DATETIME = x.DATETIME
left join temperature_nsw m on m.DATETIME = x.DATETIME
where RankValue = 1
order by x.DATETIME

